/*
Base By: Lezz DcodeR
Upgraded By: Eriza Offc
Recode By: SanzzOffc

Sosmed Creator Base:
- Tiktok Creator: https://tiktok.com/@lezzzcoder
- Github Creator: https://github.com/kyxle21
- YouTube Creator: https://youtube.com/@lezzdcoder

Jangan Lupa Untuk Menyebarkan Cinta [ ♥️ ] Dengan Membiarkan Credit Ini Tetap Ada
*/

const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "6285821701227"
global.ownername = "SanzzOffc"
global.namabot = "ѕαηzzѕуη¢"
global.botversion = "1.0"
global.linkgc = "https://chat.whatsapp.com/Ba1PW5gSYreFfl2kQTgTfb"
global.idGc = "120363308440213757@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029VaibU8cJENy5B66lOJ1o"
global.idSaluran = "120363333019033320@newsletter"
global.namaSaluran = "© SanzzOfficial"
global.zz = "`"
global.packname = 'Created By SanzzOfficial'
global.author = 'ѕαηzzѕуη¢ - V1.0'

//Thumbnail
global.imgthumb = "https://img12.pixhost.to/images/920/576071797_imgtmp.jpg"
global.imgmenu = "https://img12.pixhost.to/images/920/576071797_imgtmp.jpg"


// >~~~~~~~~ Setting Message ~~~~~~~~~< //
global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
premium: "Fitur ini khusus premium!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})